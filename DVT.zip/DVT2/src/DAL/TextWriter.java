/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;
import Entity.Application;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class TextWriter {
    private static final String FILENAME = "src/Persistance/applicants.txt";
    public static void write(Application a){
        try {
            FileWriter fw = new FileWriter(new File(FILENAME), true);
            fw.write(a.toString());
            fw.close();
        } catch (IOException ex) {
            
            JOptionPane.showMessageDialog(null, "Cannot write to file");
        }
    }
    
}
