/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author User
 */
public class Application {
    private String firstName;
    private Date age;
    private String phoneNumber;
    private String job;
    private int experience;

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public Boolean getResume() {
        return resume;
    }

    public void setResume(Boolean resume) {
        this.resume = resume;
    }
    private Boolean resume;

    public Application() {
    }

    @Override
    public String toString() {
        return  firstName + "," +  phoneNumber + "," + job + "," + age + "," + calculateAge() + "," + experience + "," + resume + "\n" ;
    }

    public Application(String firstName, Date age, String phoneNumber, String job, boolean  resume , int experience) {
        this.firstName = firstName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.job = job;
        this.resume = resume;
        this.experience = experience;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setAge(Date age) {
        this.age = age;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getFirstName() {
        return firstName;
    }

    public Date getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getJob() {
        return job;
    }
    public int calculateAge() {
        if (age == null) return 0;
        LocalDate dob = age.toLocalDate();
        LocalDate now = LocalDate.now();
        return Period.between(dob, now).getYears();
    }
    
}
